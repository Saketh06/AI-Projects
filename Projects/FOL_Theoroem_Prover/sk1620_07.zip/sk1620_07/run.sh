#!/bin/sh
java Prover.java "$@"
