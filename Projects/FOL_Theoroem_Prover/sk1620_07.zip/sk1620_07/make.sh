#!/bin/sh
javac Prover.java