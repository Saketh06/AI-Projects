#!/bin/sh
javac StripsPlanner.java