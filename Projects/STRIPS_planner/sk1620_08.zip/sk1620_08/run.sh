#!/bin/sh
java StripsPlanner.java "$@"
